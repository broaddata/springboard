## Begin Titanic data wrangling exercise
#open titanic original csv file
setwd("/data-science/data-wrangling-ex2")
titanic <- read.csv("titanic_original.csv")
#general read of the data fram
str(titanic)
#Find those observations where embarked is blank. Searches on NA or NULL didn't yield any records, but "" did.
filter(titanic, embarked == "")
#Change those observations where embarked was blank to S or Southhampton.
titanic$embarked[titanic$embarked == ""] <- "S"
#Get the mean age of all passengers who have ages listed. initial means indicated a deep decimal number, so it was rounded to the nearest whole number.
round(mean(titanic$age, trim = 0, na.rm = TRUE), digits = 0)
#Set the mean age to all of those passengers where the age was NA.
titanic$age[is.na(titanic$age)] <- round(mean(titanic$age, trim = 0, na.rm = TRUE), digits = 0)