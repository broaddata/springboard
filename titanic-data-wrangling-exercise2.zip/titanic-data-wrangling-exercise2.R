## Begin Titanic data wrangling exercise
#open titanic original csv file
setwd("/data-science/data-wrangling-ex2")
titanic <- read.csv("titanic_original.csv")
#general read of the data fram
str(titanic)
#Find those observations where embarked is blank. Searches on NA or NULL didn't yield any records, but "" did.
library(dplyr)
filter(titanic, embarked == "")
#Change those observations where embarked was blank to S or Southhampton.
titanic$embarked[titanic$embarked == ""] <- "S"
#Get the mean age of all passengers who have ages listed. initial means indicated a deep decimal number, so it was rounded to the nearest whole number.
round(mean(titanic$age, trim = 0, na.rm = TRUE), digits = 0)
#Set the mean age to all of those passengers where the age was NA.
titanic$age[is.na(titanic$age)] <- round(mean(titanic$age, trim = 0, na.rm = TRUE), digits = 0)
#Set the boat variable to NA for those observations that do not show a boat number.
filter(titanic, boat == "")
titanic$boat[titanic$boat == ""] <- NA
#Create has_cabin_number variable and set default value to 0.
titanic$has_cabin_number <- 0
#Set has_cabin_number to 1 where there is a cabin number in cabin. 
filter(titanic, cabin != "")
titanic$has_cabin_number[titanic$cabin != ""] <- 1
#Save the cleaned data frame to titanic_clean.csv"
write.csv(titanic, "titanic_clean.csv")